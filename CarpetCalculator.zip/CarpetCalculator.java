public class CarpetCalculator {
    public static void main(String[] args) {
        RoomDimension getArea = new RoomDimension();
        double theArea = getArea.area();
        double desiredPrice = getArea.desiredPrice();

        RoomCarpet getCost = new RoomCarpet();
        getCost.calculatePrice(theArea, desiredPrice);
    }
}

